        sudo g++  -m64 -g -o test main.cpp ad7606B.cpp type.h -lpthread -L/usr/local/lib -lusb-1.0


