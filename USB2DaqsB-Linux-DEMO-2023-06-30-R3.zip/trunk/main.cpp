
#include <stdio.h> 
#include <pthread.h>
#include <semaphore.h>
#include <errno.h>
#include <signal.h>
#include<unistd.h>
#include "type.h"
#define DllExport
DllExport HANDLE  M3F20xm_OpenDevice(libusb_context *pCtx);
DllExport bool M3F20xm_CloseDevice(HANDLE pDevHand);
DllExport bool M3F20xm_GetVersion(HANDLE pDevHand,BYTE byType,LPVOID lpBuffer);
DllExport bool M3F20xm_ADCGetConfig(HANDLE pDevHand, ADC_CONFIG* pCfge);
DllExport bool M3F20xm_ADCSetConfig(HANDLE pDevHand, ADC_CONFIG* pCfg);
DllExport bool M3F20xm_ADCRead(HANDLE pDevHand,WORD* lpReadBuffer);
DllExport bool M3F20xm_ADCStart(HANDLE pDevHand);
DllExport bool M3F20xm_ADCStop(HANDLE pDevHand);
DllExport bool M3F20xm_GetSerialNo(HANDLE pDevHand,char* lpBuff);
DllExport bool M3F20xm_ReadAllReg(HANDLE pDevHand, BYTE* pbyValue);
DllExport bool M3F20xm_WriteAllReg(HANDLE pDevHand, BYTE* pbyValue);
HANDLE pDevHandle = NULL;
volatile DWORD cycles;
ADC_CONFIG cfg = {0};
BYTE Ad7606B_Reg[MAX_REG_SIZE];
float MaxVol[8];
libusb_context *ctx;
//libusb_hotplug_callback_handle callbackHandle;
bool bSampled;


static void sighandler(int signum);

static volatile sig_atomic_t do_exit = 0;

static pthread_t poll_thread;
static sem_t exit_sem;

void request_exit(sig_atomic_t code)
{
	printf("request_exit = %d\n",code);
	if(bSampled)
	{
	 M3F20xm_ADCStop(pDevHandle); 	
	}
	do_exit = code;
	sem_post(&exit_sem);
}


static void *poll_thread_main(void *arg)
{
	int r = 0;
	printf("poll thread running\n");

	while (!do_exit) {
		struct timeval tv = { 1, 0 };
		r = libusb_handle_events_timeout(NULL, &tv);
		//printf("timeout = %d\n",r);
		if (r < 0) {
			
			request_exit(2);
			break;
		}
	}

	printf("poll thread shutting down\n");
	return NULL;
}


int main()
{   	 

  struct sigaction sigact;
	int r = 1;
	r = sem_init(&exit_sem, 0, 0);
	if (r) {
		fprintf(stderr, "failed to initialise semaphore error %d", errno);
		return -1;
	}
	r = libusb_init(&ctx);
  if(r<0)
  {
       printf("libusb_init error\n");
       sem_destroy(&exit_sem);
       return -1;
  }
   else
       libusb_set_debug(ctx,3);  
  pDevHandle = M3F20xm_OpenDevice(ctx);
	if(!pDevHandle)
	{
	 printf("M3F20xm_OpenDevice fail\n"); 
	 libusb_exit(ctx);		
	 sem_destroy(&exit_sem);	
	 return -1;
	}
	/* async from here onwards */

	sigact.sa_handler = sighandler;
	sigemptyset(&sigact.sa_mask);
	sigact.sa_flags = 0;
	sigaction(SIGINT, &sigact, NULL);
	sigaction(SIGTERM, &sigact, NULL);
	sigaction(SIGQUIT, &sigact, NULL);
	
	r = pthread_create(&poll_thread, NULL, poll_thread_main, NULL);
	if (r)
	{
	 printf("pthread_create fail\n"); 
	 libusb_exit(ctx);		
	 sem_destroy(&exit_sem);	
	 return -1;
	}
	if(!M3F20xm_ADCGetConfig(pDevHandle,&cfg))//  read ADC
	{
		M3F20xm_CloseDevice(pDevHandle);
		pDevHandle = NULL;
		libusb_exit(ctx);
		sem_destroy(&exit_sem);	
		return -1;
	}

	 cfg.byADCOptions = 0x01; //uint:us,  period trig
	
   cfg.wPeriod = 10;    //100K
   cfg.dwMaxCycles = 700000; //sample 5000 cycles
 
	if(!M3F20xm_ADCSetConfig(pDevHandle,&cfg))
	{
		printf("call M3F20xm_ADCSetConfig fail\n"); 
		M3F20xm_CloseDevice(pDevHandle);
		pDevHandle = NULL;
		libusb_exit(ctx);
		sem_destroy(&exit_sem);	
		return -1;
	}	     	
	 M3F20xm_ReadAllReg(pDevHandle,Ad7606B_Reg);
	 printf("dev id = %02x\n", Ad7606B_Reg[46]); //see if it is 0x14 when read data is right
	 MaxVol[0] = ((Ad7606B_Reg[2] & 0x03) + 1 ) * 2.5;
	 MaxVol[1] = (((Ad7606B_Reg[2] >> 4)& 0x03) + 1 ) * 2.5;
	 MaxVol[2] = ((Ad7606B_Reg[3] & 0x03) + 1 ) * 2.5;
	 MaxVol[3] = (((Ad7606B_Reg[3] >> 4)& 0x03) + 1 ) * 2.5;
	 MaxVol[4] = ((Ad7606B_Reg[4] & 0x03) + 1 ) * 2.5;
	 MaxVol[5] = (((Ad7606B_Reg[4] >> 4)& 0x03) + 1 ) * 2.5;
	 MaxVol[6] = ((Ad7606B_Reg[5] & 0x03) + 1 ) * 2.5;
	 MaxVol[7] = (((Ad7606B_Reg[5] >> 4)& 0x03) + 1 ) * 2.5;
	 
   WORD adc_value[8];    
  
   if(!M3F20xm_ADCRead(pDevHandle,adc_value))//  read adc value once
    {
       printf("call M3F20xm_ADCRead fail\n"); 
       M3F20xm_CloseDevice(pDevHandle);
       libusb_exit(ctx);
       sem_destroy(&exit_sem);
       return -1; 
    }
    printf("%04X %04X %04X %04X %04X %04X %04X %04X\n",adc_value[0],adc_value[1],adc_value[2],adc_value[3],adc_value[4],adc_value[5],adc_value[6],adc_value[7]);
    bSampled = M3F20xm_ADCStart(pDevHandle);   //start ADC continuous sampling ;    
    cycles = 0;
     
    while (!do_exit)
    {
		// printf("cycles = %d\n",cycles);
		 sem_wait(&exit_sem);
		}
		
    
    printf("shutting down...\n");
    pthread_join(poll_thread, NULL);
    M3F20xm_CloseDevice(pDevHandle);
    if (do_exit == 1)
		 r = 0;
	  else
		 r = 1; 
		libusb_exit(ctx);
    sem_destroy(&exit_sem);
	  return r >= 0 ? r : -r;
    
}

static void sighandler(int signum)
{
	request_exit(1);
}

