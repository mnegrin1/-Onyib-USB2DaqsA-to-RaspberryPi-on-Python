#ifndef TYPE_H
#define TYPE_H
#include <libusb-1.0/libusb.h>
typedef    unsigned char BYTE ;
typedef    unsigned  short WORD;
typedef    unsigned  int     DWORD;
typedef    void          VOID;
typedef    void*         LPVOID;
typedef    libusb_device_handle* HANDLE;
#define FALSE  0
#define TRUE   1

#define USBD_VID                      0x0483
#define USBD_PID                      0x8011


#define BULK_IN_EP                                     0x81
#define BULK_OUT_EP                                    0x01
#define INT_IN_EP                                      0x82
#define INT_OUT_EP                                     0x02

#define DEV_UART     0x80
#define DEV_I2C      0x81
#define DEV_SPI      0x82
#define DEV_POLL     0x83
#define DEV_CAN      0x84
#define DEV_GPIO     0x85
#define DEV_ADC      0x86
#define DEV_PWM      0x87
#define DEV_PARALLEL 0x88
#define DEV_MEM      0x8D
#define DEV_TRIG     0x8E
#define DEV_ALL      0x8F

#define OP_READ      0x10
#define OP_WRITE     0x11
#define OP_CONFIG    0x12
#define OP_QUERY     0x13
#define OP_RESET     0x14
#define OP_VERSION   0x15
#define OP_QUERY_DFU       0x16
#define OP_VERIFY          0x17
#define OP_STATUS          0x18
#define OP_TEST            0x19
#define OP_READ_REG        0x1A
#define OP_WRITE_REG       0x1B

#define OP_START           0x20
#define OP_STOP            0x21
#define OP_ENTER_DFU       0x23

#define MODE_DMA     0x01
#define MODE_DIR     0x02

#define IOCTL_READ_DATA     0xF000
#define IOCTL_WRITE_DATA    0xF001
#define IOCTL_READ_TRIG     0xF002
#define IOCTL_READ_VER      0xF00E

#define IOCTL_GET_ADDRESS    (DEV_I2C<<8|OP_ADDRESS)
#define IOCTL_SET_I2C    (DEV_I2C<<8|OP_CONFIG)
#define IOCTL_GET_I2C    (DEV_I2C<<8|OP_QUERY)
#define IOCTL_SET_SPI    (DEV_SPI<<8|OP_CONFIG)
#define IOCTL_GET_SPI    (DEV_SPI<<8|OP_QUERY)
#define IOCTL_SET_TIMER  (DEV_TIMER<<8|OP_CONFIG)
#define IOCTL_GET_TIMER  (DEV_TIMER<<8|OP_QUERY)

#define IOCTL_SET_GPIO   (DEV_GPIO<<8|OP_CONFIG)
#define IOCTL_GET_GPIO   (DEV_GPIO<<8|OP_QUERY)
#define IOCTL_SET_TRIG   (DEV_TRIG<<8|OP_CONFIG)
#define IOCTL_GET_TRIG   (DEV_TRIG<<8|OP_QUERY)
#define IOCTL_START_TRIG (DEV_TRIG<<8|OP_START)
#define IOCTL_STOP_TRIG  (DEV_TRIG<<8|OP_STOP)
#define IOCTL_GET_PWM    (DEV_PWM<<8|OP_QUERY)
#define IOCTL_SET_PWM    (DEV_PWM<<8|OP_CONFIG)
#define IOCTL_START_PWM  (DEV_PWM<<8|OP_START)
#define IOCTL_STOP_PWM   (DEV_PWM<<8|OP_STOP)
#define IOCTL_GET_ADC    (DEV_ADC<<8|OP_QUERY)
#define IOCTL_SET_ADC    (DEV_ADC<<8|OP_CONFIG)
#define IOCTL_START_ADC  (DEV_ADC<<8|OP_START)
#define IOCTL_STOP_ADC   (DEV_ADC<<8|OP_STOP)
#define IOCTL_SET_BUFF   (DEV_MEM<<8|OP_CONFIG)
#define IOCTL_GET_BUFF   (DEV_MEM<<8|OP_QUERY)


#define MAX_REG_SIZE          0x2F
#define AUTO_SAVE_CYCLE       6000000


typedef struct
 {
	/*
	  bit7     for AD7606B samping:                1- in sampling,    0- stop
	  bit6     unused
	  bit5     for AD7606B period unit             0- US, 1- MS
	  bit4     for AD7606B trig vol:               0- larger or equal,   1- less or equal
	  bit2~3   for AD7606B IO selection:           00- falling, 01- Raising , 10- raising and falling
	  bit0~1   for AD7606B trig mode;              00- GPIO trig, 01- period trig, 10- GPIO + period, 11--value
	*/

	uint8_t  byADCOptions;
	uint8_t  byGPIO;
	uint8_t  byActived; 
	uint8_t  byReserved;
	uint16_t wTrigVol;	
	uint16_t wPeriod;
	uint16_t wPreNum; //unused
	uint16_t wReserved;
 /* dwTrigCnt: current trig counter */
	uint32_t dwCycleCnt;
  /* dwMaxCnt: Max Enabled trig number , trig will exit if dwTrigCnt is equal to dwMaxCnt */
	uint32_t dwMaxCycles;
	uint32_t dwReserved;

 }ADC_CONFIG;


#endif // TYPE_H
